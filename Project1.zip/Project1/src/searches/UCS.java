package searches;

import gui.model.Grid;

public class UCS extends SearchAlgo {
	public UCS(Node start, Node goal, Grid grid) {
		super(start, goal, grid);
	}
}
